class GameFooter extends HTMLElement {
    connectedCallback() {
        this.attachShadow({ mode: 'open' });
        this.shadowRoot.innerHTML = `
            <style>
                footer {
                    background-color: #1a202c;
                    border-top: 4px solid #4a5568;
                    padding: 2rem;
                    text-align: center;
                    color: #a0aec0;
                }
                
                .footer-content {
                    max-width: 1200px;
                    margin: 0 auto;
                }
                
                .footer-links {
                    display: flex;
                    justify-content: center;
                    gap: 1.5rem;
                    margin-bottom: 1rem;
                }
                
                .footer-link {
                    color: #e2e8f0;
                    text-decoration: none;
                    transition: color 0.2s;
                }
                
                .footer-link:hover {
                    color: #f6ad55;
                }
                
                .copyright {
                    font-size: 0.875rem;
                }
            </style>
            <footer>
                <div class="footer-content">
                    <div class="footer-links">
                        <a href="#" class="footer-link">Docs</a>
                        <a href="#" class="footer-link">GitHub</a>
                        <a href="#" class="footer-link">Support</a>
                        <a href="#" class="footer-link">Community</a>
                    </div>
                    <p class="copyright">© 2023 PixelQuest: 8-Bit Adventure Forge. All rights reserved.</p>
                </div>
            </footer>
        `;
    }
}

customElements.define('game-footer', GameFooter);