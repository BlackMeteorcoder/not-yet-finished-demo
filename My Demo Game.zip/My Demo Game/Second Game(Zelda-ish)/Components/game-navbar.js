class GameNavbar extends HTMLElement {
    connectedCallback() {
        this.attachShadow({ mode: 'open' });
        this.shadowRoot.innerHTML = `
            <style>
                nav {
                    background-color: #1a202c;
                    border-bottom: 4px solid #4a5568;
                    padding: 1rem 2rem;
                }
                
                .nav-container {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    max-width: 1200px;
                    margin: 0 auto;
                }
                
                .logo {
                    font-family: 'Press Start 2P', cursive;
                    color: #f6ad55;
                    font-size: 1.5rem;
                    text-decoration: none;
                }
                
                .nav-links {
                    display: flex;
                    gap: 1.5rem;
                }
                
                .nav-link {
                    color: #e2e8f0;
                    text-decoration: none;
                    font-weight: 500;
                    transition: color 0.2s;
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                }
                
                .nav-link:hover {
                    color: #f6ad55;
                }
                
                @media (max-width: 768px) {
                    .nav-container {
                        flex-direction: column;
                        gap: 1rem;
                    }
                }
            </style>
            <nav>
                <div class="nav-container">
                    <a href="index.html" class="logo">PIXELQUEST</a>
                    <div class="nav-links">
                        <a href="editor.html" class="nav-link">
                            <i data-feather="edit-3"></i>
                            Editor
                        </a>
                        <a href="character.html" class="nav-link">
                            <i data-feather="user"></i>
                            Character
                        </a>
                        <a href="play.html" class="nav-link">
                            <i data-feather="play"></i>
                            Play
                        </a>
                        <a href="settings.html" class="nav-link">
                            <i data-feather="settings"></i>
                            Settings
                        </a>
                    </div>
                </div>
            </nav>
        `;
        
        // Replace feather icons after rendering
        setTimeout(() => {
            if (this.shadowRoot.querySelectorAll('[data-feather]').length > 0) {
                feather.replace();
            }
        }, 100);
    }
}

customElements.define('game-navbar', GameNavbar);