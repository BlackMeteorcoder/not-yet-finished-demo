// Base game configuration
const gameConfig = {
    tileSize: 32,
    playerSpeed: 150,
    gravity: 800,
    jumpForce: 400,
    worldBounds: {
        width: 1280,
        height: 720
    },
    defaultLevel: 'level1',
    character: {
        sprite: 'hero',
        color: '#ff5555',
        weapons: ['sword', 'bow']
    }
};

// Initialize game settings from localStorage or use defaults
function initGameSettings() {
    if (!localStorage.getItem('pixelQuestSettings')) {
        localStorage.setItem('pixelQuestSettings', JSON.stringify(gameConfig));
    }
}

// Simple event bus for component communication
const EventBus = {
    events: {},
    
    emit(event, data) {
        if (!this.events[event]) return;
        this.events[event].forEach(callback => callback(data));
    },
    
    on(event, callback) {
        if (!this.events[event]) this.events[event] = [];
        this.events[event].push(callback);
    }
};

// Expose to window so other scripts/components can access them
window.EventBus = EventBus;
window.initGameSettings = initGameSettings;

// Initialize when DOM is loaded (handles case where DOMContentLoaded already fired)
function onDomReady() {
    initGameSettings();
    if (window.feather && typeof feather.replace === 'function') {
        feather.replace();
    }
    
    // Load saved character if exists
    const savedCharacter = localStorage.getItem('pixelQuestCharacter');
    if (savedCharacter) {
        EventBus.emit('characterLoaded', JSON.parse(savedCharacter));
    }
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', onDomReady);
} else {
    onDomReady();
}