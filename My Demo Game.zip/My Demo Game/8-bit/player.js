export function createPlayer(data, groundY) {
  return {
    x: 100, y: groundY - 60, width: 32, height: 60,
    dy: 0, grounded: true, attacking: false,
    ...data
  };
}

export function updatePlayer(p, keys, groundY, attackSound) {
  p.dy += 0.6;
  p.y += p.dy;

  if (p.y + p.height >= groundY) {
    p.y = groundY - p.height;
    p.dy = 0;
    p.grounded = true;
  }

  if (keys['ArrowLeft']) p.x -= 4;
  if (keys['ArrowRight']) p.x += 4;
  if (keys[' '] && p.grounded) {
    p.dy = -12;
    p.grounded = false;
  }

  p.attacking = keys['a'];
  if (p.attacking) attackSound.play();
}

export function drawPlayer(ctx, p) {
  ctx.fillStyle = 'brown';
  ctx.fillRect(p.x + 6, p.y + 45, 8, 15);
  ctx.fillRect(p.x + 18, p.y + 45, 8, 15);
  ctx.fillStyle = p.outfit;
  ctx.fillRect(p.x + 4, p.y + 20, 24, 25);
  ctx.fillStyle = p.skin;
  ctx.fillRect(p.x - 4, p.y + 20, 8, 20);
  ctx.fillRect(p.x + 28, p.y + 20, 8, 20);
  ctx.fillRect(p.x + 8, p.y, 16, 20);
  ctx.fillStyle = 'black';
  ctx.fillRect(p.x + 12, p.y + 6, 2, 2);
  ctx.fillRect(p.x + 18, p.y + 6, 2, 2);
}