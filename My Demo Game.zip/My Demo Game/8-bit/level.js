import { enemies } from './enemy.js';
import { npcs } from './npc.js';

export const levels = {
  1: {
    enemies: [{ x: 500, y: 540, width: 32, height: 60, dx: -1, color: 'red' }],
    traps: [],
    npcs: [{ x: 200, y: 540, width: 32, height: 60, color: 'yellow', dialogue: "Find the sword!" }]
  },
  2: {
    enemies: [
      { x: 400, y: 540, width: 32, height: 60, dx: -2, color: 'darkred' },
      { x: 600, y: 540, width: 32, height: 60, dx: 2, color: 'darkred' }
    ],
    traps: [],
    npcs: [{ x: 100, y: 540, width: 32, height: 60, color: 'orange', dialogue: "Beware of the enemies!" }]
  }
};  