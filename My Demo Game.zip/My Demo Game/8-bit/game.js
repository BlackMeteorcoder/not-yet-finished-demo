import { createPlayer, drawPlayer, updatePlayer } from './player.js';
import { loadLevel, levels } from './level.js';
import { updateEnemies, enemies } from './enemy.js';
import { updateNPCs, npcs } from './npc.js';
import { saveCharacter } from './save.js';

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const attackSound = document.getElementById('attackSound');

let player = {};
let keys = {};
let currentLevel = 1;
let groundY = canvas.height - 50;

document.getElementById('startButton').addEventListener('click', () => {
  document.getElementById('startScreen').style.display = 'none';
  canvas.style.display = 'block';

  const data = {
    class: document.getElementById('classSelect').value,
    race: document.getElementById('raceSelect').value,
    skin: document.getElementById('skinSelect').value,
    outfit: document.getElementById('outfitSelect').value,
    hat: document.getElementById('hatSelect').value
  };

  saveCharacter(data);
  player = createPlayer(data, groundY);
  loadLevel(currentLevel, groundY);

  document.addEventListener('keydown', e => keys[e.key] = true);
  document.addEventListener('keyup', e => keys[e.key] = false);

  requestAnimationFrame(gameLoop);
});

function gameLoop() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  updatePlayer(player, keys, groundY, attackSound);
  drawPlayer(ctx, player);

  updateEnemies(ctx, player, keys, canvas, () => {
    currentLevel++;
    if (levels[currentLevel]) {
      loadLevel(currentLevel, groundY);
      player.x = 100;
      player.y = groundY - player.height;
    } else {
      alert("You beat the game!");
      location.reload();
    }
  });

  updateNPCs(ctx, player, keys);

  requestAnimationFrame(gameLoop);
}