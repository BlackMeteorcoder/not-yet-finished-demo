export let enemies = [];

export function updateEnemies(ctx, player, keys, canvas, onClear) {
  enemies.forEach(e => {
    ctx.fillStyle = e.color;
    ctx.fillRect(e.x, e.y, e.width, e.height);
    e.x += e.dx;
    if (e.x < 0 || e.x + e.width > canvas.width) e.dx *= -1;

    if (collision(player, e)) {
      if (player.attacking) {
        enemies = enemies.filter(en => en !== e);
      } else {
        alert("You were hit!");
        location.reload();
      }
    }
  });

  if (enemies.length === 0) onClear();
}

function collision(a, b) {
  return a.x < b.x + b.width &&
         a.x + a.width > b.x &&
         a.y < b.y + b.height &&
         a.y + a.height > b.y;
}