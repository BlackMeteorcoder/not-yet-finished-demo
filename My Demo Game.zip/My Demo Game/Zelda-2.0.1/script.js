// Initialize pixel cursor
document.addEventListener('DOMContentLoaded', function() {
    const cursor = document.createElement('div');
    cursor.classList.add('pixel-cursor');
    document.body.appendChild(cursor);
    
    document.addEventListener('mousemove', function(e) {
        cursor.style.left = e.pageX + 'px';
        cursor.style.top = e.pageY + 'px';
    });

    // Add retro game sound effects
    const buttons = document.querySelectorAll('a, button');
    buttons.forEach(button => {
        button.addEventListener('click', function() {
            const audio = new Audio('https://assets.mixkit.co/sfx/preview/mixkit-retro-arcade-casino-notification-211.mp3');
            audio.volume = 0.3;
            audio.play();
        });
    });

    // Load font
    const font = new FontFace('Press Start 2P', 'url(https://fonts.gstatic.com/s/pressstart2p/v14/e3t4euO8T-267oIAQAu6jDQyK3nVivM.woff2)');
    font.load().then(function(loadedFont) {
        document.fonts.add(loadedFont);
    }).catch(function(error) {
        console.log('Font loading failed: ' + error);
    });
});

// Game state management
const gameState = {
    player: null,
    currentDungeon: null,
    inventory: [],
    score: 0,
    loadGame: function() {
        const savedGame = localStorage.getItem('pixelDungeonSave');
        if (savedGame) {
            Object.assign(this, JSON.parse(savedGame));
        }
    },
    saveGame: function() {
        localStorage.setItem('pixelDungeonSave', JSON.stringify(this));
    },
    resetGame: function() {
        this.player = null;
        this.currentDungeon = null;
        this.inventory = [];
        this.score = 0;
        localStorage.removeItem('pixelDungeonSave');
    }
};

// Initialize game state
document.addEventListener('DOMContentLoaded', gameState.loadGame);