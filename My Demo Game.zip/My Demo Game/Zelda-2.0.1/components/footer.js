class CustomHeader extends HTMLElement {
    connectedCallback() {
        this.attachShadow({ mode: 'open' });
        this.shadowRoot.innerHTML = `
            <style>
                header {
                    background-color: #2D3748;
                    border-bottom: 4px solid #6B46C1;
                    padding: 1rem 2rem;
                }
                nav {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    max-width: 1200px;
                    margin: 0 auto;
                }
                .logo {
                    font-family: 'Press Start 2P', cursive;
                    font-size: 1.5rem;
                    color: #F6AD55;
                    text-decoration: none;
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                }
                .nav-links {
                    display: flex;
                    gap: 1.5rem;
                }
                .nav-links a {
                    color: white;
                    text-decoration: none;
                    font-family: 'Press Start 2P', cursive;
                    font-size: 0.8rem;
                    position: relative;
                    padding: 0.5rem 0;
                }
                .nav-links a:hover {
                    color: #F6AD55;
                }
                .nav-links a::after {
                    content: '';
                    position: absolute;
                    bottom: 0;
                    left: 0;
                    width: 0;
                    height: 2px;
                    background-color: #F6AD55;
                    transition: width 0.3s ease;
                }
                .nav-links a:hover::after {
                    width: 100%;
                }
                @media (max-width: 768px) {
                    nav {
                        flex-direction: column;
                        gap: 1rem;
                    }
                    .nav-links {
                        width: 100%;
                        justify-content: space-around;
                    }
                }
            </style>
            <header>
                <nav>
                    <a href="index.html" class="logo">
                        <i data-feather="crosshair"></i>
                        PIXEL DUNGEON
                    </a>
                    <div class="nav-links">
                        <a href="character.html">
                            <i data-feather="user"></i>
                            Character
                        </a>
                        <a href="play.html">
                            <i data-feather="play"></i>
                            Play
                        </a>
                        <a href="builder.html">
                            <i data-feather="edit-3"></i>
                            Builder
                        </a>
                        <a href="about.html">
                            <i data-feather="info"></i>
                            About
                        </a>
                    </div>
                </nav>
            </header>
        `;
    }
}
customElements.define('custom-header', CustomHeader);