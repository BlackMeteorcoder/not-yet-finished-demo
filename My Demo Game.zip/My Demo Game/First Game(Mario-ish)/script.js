document.addEventListener('DOMContentLoaded', () => {
    // Game elements
    const gameContainer = document.getElementById('game-container');
    const startScreen = document.getElementById('start-screen');
    const gameOverScreen = document.getElementById('game-over');
    const startBtn = document.getElementById('start-btn');
    const restartBtn = document.getElementById('restart-btn');
    const scoreDisplay = document.getElementById('score');
    const livesDisplay = document.getElementById('lives');
    const finalScoreDisplay = document.getElementById('final-score');
    
    // Game variables
    let character;
    let platforms = [];
    let coins = [];
    let enemies = [];
    let powerups = [];
    let clouds = [];
    let gameWidth = window.innerWidth;
    let gameHeight = window.innerHeight;
    let score = 0;
    let lives = 3;
    let isJumping = false;
    let isGameOver = false;
    let isInvincible = false;
    let gameSpeed = 5;
    let gravity = 1.5;
    let velocityY = 0;
    let positionX = 100;
    let positionY = 100;
    let keys = {};
    let gameInterval;
    
    // Event listeners
    startBtn.addEventListener('click', startGame);
    restartBtn.addEventListener('click', restartGame);
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    
    // Initialize game
    function initGame() {
        // Create character
        character = document.createElement('div');
        character.className = 'character';
        character.style.left = positionX + 'px';
        character.style.top = positionY + 'px';
        gameContainer.appendChild(character);
        
        // Create platforms
        createInitialPlatforms();
        
        // Create clouds
        createClouds();
    }
    
    function createInitialPlatforms() {
        // Ground platform
        const ground = createPlatform(0, gameHeight - 50, gameWidth, 50);
        platforms.push(ground);
        
        // Some floating platforms
        for (let i = 0; i < 5; i++) {
            const width = 150 + Math.random() * 100;
            const x = 300 + i * 300 + Math.random() * 200;
            const y = gameHeight - 150 - i * 150;
            platforms.push(createPlatform(x, y, width, 20));
            
            // Add coins on some platforms
            if (Math.random() > 0.3) {
                coins.push(createCoin(x + width/2 - 15, y - 40));
            }
            
            // Add enemies on some platforms
            if (i > 1 && Math.random() > 0.6) {
                enemies.push(createEnemy(x + 20, y - 50));
            }
            
            // Add powerups occasionally
            if (i > 2 && Math.random() > 0.8) {
                const powerupType = Math.random() > 0.5 ? 'invincible' : 'double-jump';
                powerups.push(createPowerup(x + width/2 - 20, y - 60, powerupType));
            }
        }
        
        // Add flag at the end
        const flag = document.createElement('div');
        flag.className = 'flag';
        flag.style.left = (gameWidth - 100) + 'px';
        flag.style.bottom = '50px';
        gameContainer.appendChild(flag);
    }
    
    function createPlatform(x, y, width, height) {
        const platform = document.createElement('div');
        platform.className = 'platform';
        platform.style.left = x + 'px';
        platform.style.top = y + 'px';
        platform.style.width = width + 'px';
        platform.style.height = height + 'px';
        gameContainer.appendChild(platform);
        return { element: platform, x, y, width, height };
    }
    
    function createCoin(x, y) {
        const coin = document.createElement('div');
        coin.className = 'coin';
        coin.style.left = x + 'px';
        coin.style.top = y + 'px';
        gameContainer.appendChild(coin);
        return { element: coin, x, y, collected: false };
    }
    
    function createEnemy(x, y) {
        const enemy = document.createElement('div');
        enemy.className = 'enemy';
        enemy.style.left = x + 'px';
        enemy.style.top = y + 'px';
        gameContainer.appendChild(enemy);
        return { element: enemy, x, y, direction: 1, speed: 2 + Math.random() * 2 };
    }
    
    function createPowerup(x, y, type) {
        const powerup = document.createElement('div');
        powerup.className = 'powerup';
        powerup.style.left = x + 'px';
        powerup.style.top = y + 'px';
        
        // Different powerup types
        if (type === 'invincible') {
            powerup.style.backgroundImage = 'url("http://static.photos/blue/200x200/1")';
        } else if (type === 'double-jump') {
            powerup.style.backgroundImage = 'url("http://static.photos/yellow/200x200/2")';
        }
        
        gameContainer.appendChild(powerup);
        return { element: powerup, x, y, type, collected: false };
    }
    
    function createClouds() {
        for (let i = 0; i < 5; i++) {
            const cloud = document.createElement('div');
            cloud.className = 'cloud';
            cloud.style.left = Math.random() * gameWidth + 'px';
            cloud.style.top = (50 + Math.random() * 200) + 'px';
            cloud.style.width = (80 + Math.random() * 100) + 'px';
            cloud.style.height = (30 + Math.random() * 40) + 'px';
            gameContainer.appendChild(cloud);
            clouds.push({ element: cloud, speed: 0.5 + Math.random() });
        }
    }
    
    function startGame() {
        startScreen.style.display = 'none';
        isGameOver = false;
        score = 0;
        lives = 3;
        updateScore();
        updateLives();
        initGame();
        gameInterval = setInterval(updateGame, 20);
    }
    
    function restartGame() {
        // Clear all game elements
        gameContainer.innerHTML = `
            <div id="game-ui" class="absolute top-4 left-4 flex gap-8 text-white">
                <div class="flex items-center gap-2">
                    <i data-feather="star" class="text-yellow-300"></i>
                    <span id="score">0</span>
                </div>
                <div class="flex items-center gap-2">
                    <i data-feather="heart" class="text-red-500"></i>
                    <span id="lives">3</span>
                </div>
            </div>
        `;
        feather.replace();
        
        // Reset game variables
        platforms = [];
        coins = [];
        enemies = [];
        powerups = [];
        clouds = [];
        positionX = 100;
        positionY = 100;
        velocityY = 0;
        keys = {};
        
        gameOverScreen.style.display = 'none';
        startGame();
    }
    
    function updateGame() {
        if (isGameOver) return;
        
        handleInput();
        applyGravity();
        checkCollisions();
        moveEnemies();
        moveClouds();
        checkGameStatus();
    }
    
    function handleInput() {
        if (keys['ArrowLeft']) {
            positionX = Math.max(20, positionX - 5);
        }
        if (keys['ArrowRight']) {
            positionX = Math.min(gameWidth - 70, positionX + 5);
        }
        if (keys[' '] && !isJumping) {
            jump();
        }
        
        character.style.left = positionX + 'px';
        character.style.top = positionY + 'px';
    }
    
    function applyGravity() {
        velocityY += gravity;
        positionY += velocityY;
        
        // Check for platform collisions
        let onPlatform = false;
        for (const platform of platforms) {
            if (
                positionY + 80 >= platform.y &&
                positionY + 80 <= platform.y + 20 &&
                positionX + 50 > platform.x &&
                positionX < platform.x + platform.width
            ) {
                positionY = platform.y - 80;
                velocityY = 0;
                isJumping = false;
                onPlatform = true;
            }
        }
        
        // If not on any platform and not jumping, start falling
        if (!onPlatform && velocityY === 0) {
            isJumping = true;
        }
        
        // Prevent falling through bottom
        if (positionY > gameHeight - 80) {
            positionY = gameHeight - 80;
            velocityY = 0;
            isJumping = false;
        }
    }
    
    function jump() {
        if (!isJumping) {
            velocityY = -20;
            isJumping = true;
            character.classList.add('jump');
            setTimeout(() => character.classList.remove('jump'), 500);
        }
    }
    
    function checkCollisions() {
        // Check coin collisions
        for (const coin of coins) {
            if (!coin.collected && isColliding(character, coin.element)) {
                coin.collected = true;
                coin.element.remove();
                score += 100;
                updateScore();
                
                // Play coin sound
                const audio = new Audio('https://assets.mixkit.co/sfx/preview/mixkit-coin-win-notification-1992.mp3');
                audio.play();
            }
        }
        
        // Check powerup collisions
        for (const powerup of powerups) {
            if (!powerup.collected && isColliding(character, powerup.element)) {
                powerup.collected = true;
                powerup.element.remove();
                
                // Apply powerup effect
                if (powerup.type === 'invincible') {
                    isInvincible = true;
                    character.classList.add('invincible');
                    setTimeout(() => {
                        isInvincible = false;
                        character.classList.remove('invincible');
                    }, 5000);
                } else if (powerup.type === 'double-jump') {
                    // Implement double jump logic
                    // (This would require additional code to track jumps)
                }
                
                // Play powerup sound
                const audio = new Audio('https://assets.mixkit.co/sfx/preview/mixkit-achievement-bell-600.mp3');
                audio.play();
            }
        }
        
        // Check enemy collisions
        for (const enemy of enemies) {
            if (isColliding(character, enemy.element)) {
                if (isInvincible) {
                    // If invincible, enemy is defeated
                    enemy.element.remove();
                    enemies = enemies.filter(e => e !== enemy);
                    score += 200;
                    updateScore();
                    
                    // Play enemy defeat sound
                    const audio = new Audio('https://assets.mixkit.co/sfx/preview/mixkit-quick-jump-arcade-game-239.mp3');
                    audio.play();
                } else {
                    // Player gets hit
                    lives--;
                    updateLives();
                    
                    if (lives <= 0) {
                        gameOver();
                    } else {
                        // Bounce back when hit
                        positionX -= 50;
                        velocityY = -15;
                        
                        // Play hit sound
                        const audio = new Audio('https://assets.mixkit.co/sfx/preview/mixkit-player-losing-or-failing-2042.mp3');
                        audio.play();
                    }
                }
            }
        }
    }
    
    function moveEnemies() {
        for (const enemy of enemies) {
            // Simple back and forth movement
            enemy.x += enemy.direction * enemy.speed;
            enemy.element.style.left = enemy.x + 'px';
            
            // Check platform bounds
            const platform = platforms.find(p => 
                enemy.y + 50 >= p.y && 
                enemy.y + 50 <= p.y + 20 && 
                enemy.x + 50 > p.x && 
                enemy.x < p.x + p.width
            );
            
            if (platform) {
                // Change direction if at platform edge
                if (enemy.x <= platform.x || enemy.x + 50 >= platform.x + platform.width) {
                    enemy.direction *= -1;
                }
            }
        }
    }
    
    function moveClouds() {
        for (const cloud of clouds) {
            const currentLeft = parseInt(cloud.element.style.left);
            cloud.element.style.left = (currentLeft - cloud.speed) + 'px';
            
            // Reset cloud position when it goes off screen
            if (currentLeft < -200) {
                cloud.element.style.left = gameWidth + 'px';
            }
        }
    }
    
    function checkGameStatus() {
        // Check if player reached the flag
        if (positionX + 50 >= gameWidth - 100) {
            winGame();
        }
    }
    
    function winGame() {
        clearInterval(gameInterval);
        score += 1000;
        updateScore();
        
        // Show win message
        gameOverScreen.querySelector('h1').textContent = 'LEVEL COMPLETE!';
        gameOverScreen.querySelector('h1').className = 'text-4xl mb-6 text-green-500';
        finalScoreDisplay.textContent = score;
        gameOverScreen.style.display = 'flex';
        isGameOver = true;
        
        // Play win sound
        const audio = new Audio('https://assets.mixkit.co/sfx/preview/mixkit-winning-chimes-2015.mp3');
        audio.play();
    }
    
    function gameOver() {
        clearInterval(gameInterval);
        finalScoreDisplay.textContent = score;
        gameOverScreen.style.display = 'flex';
        isGameOver = true;
        
        // Reset game over title in case it was changed by win
        gameOverScreen.querySelector('h1').textContent = 'GAME OVER';
        gameOverScreen.querySelector('h1').className = 'text-4xl mb-6 text-red-500';
        
        // Play game over sound
        const audio = new Audio('https://assets.mixkit.co/sfx/preview/mixkit-retro-arcade-lose-2027.mp3');
        audio.play();
    }
    
    function updateScore() {
        scoreDisplay.textContent = score;
    }
    
    function updateLives() {
        livesDisplay.textContent = lives;
    }
    
    function isColliding(element1, element2) {
        const rect1 = element1.getBoundingClientRect();
        const rect2 = element2.getBoundingClientRect();
        
        return !(
            rect1.right < rect2.left || 
            rect1.left > rect2.right || 
            rect1.bottom < rect2.top || 
            rect1.top > rect2.bottom
        );
    }
    
    function handleKeyDown(e) {
        keys[e.key] = true;
    }
    
    function handleKeyUp(e) {
        keys[e.key] = false;
    }
    
    // Handle window resize
    window.addEventListener('resize', () => {
        gameWidth = window.innerWidth;
        gameHeight = window.innerHeight;
    });
});